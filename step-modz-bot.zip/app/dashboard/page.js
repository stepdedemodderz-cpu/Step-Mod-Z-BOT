export default function Dashboard() {
  return (
    <div style={{background:"black",color:"white",minHeight:"100vh",padding:40}}>
      <h1>Dashboard</h1>
      <p>Dein Discord Dashboard läuft 🔥</p>
      <a href="/api/auth/discord/login">Login mit Discord</a>
    </div>
  );
}