export default function Home() {
  return (
    <div style={{background:"black",color:"white",height:"100vh",display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column"}}>
      <h1>Step_Mod!Z Bot</h1>
      <a href="/dashboard" style={{marginTop:20,padding:10,background:"red",color:"white",borderRadius:10}}>Zum Dashboard</a>
    </div>
  );
}